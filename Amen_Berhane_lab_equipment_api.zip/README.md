# Lab Equipment API

## Setup

1. Install dependencies:
   ```bash
   bundle install
   ```

2. Setup database:
   ```bash
   rails db:create db:migrate db:seed
   ```

3. Start server:
   ```bash
   rails server
   ```

## API Endpoints

### Equipment (Task 4)

- `GET /equipment` - List all equipment (ordered by name, supports `?status=` filter, includes category)
- `GET /equipment/:id` - Show equipment (includes category and maintenance records ordered by performed_at DESC)
- `POST /equipment` - Create equipment (requires valid category_id)
- `PATCH/PUT /equipment/:id` - Update equipment
- `DELETE /equipment/:id` - Delete equipment (cascades to maintenance records)

### Maintenance Records (Task 5)

- `GET /maintenance_records` - List all maintenance records (ordered by performed_at DESC, supports `?equipment_id=` filter)
- `GET /maintenance_records/:id` - Show maintenance record (includes equipment)
- `POST /maintenance_records` - Create maintenance record (requires valid equipment_id)
- `PATCH/PUT /maintenance_records/:id` - Update maintenance record
- `DELETE /maintenance_records/:id` - Delete maintenance record

## Testing Filtering

```bash
# Test equipment status filtering
curl "http://localhost:3000/equipment?status=maintenance"

# Test maintenance records by equipment
curl "http://localhost:3000/maintenance_records?equipment_id=1"
```

## Models

- **Category**: has_many :equipment (dependent: :restrict_with_error)
- **Equipment**: belongs_to :category, has_many :maintenance_records (dependent: :destroy)
- **MaintenanceRecord**: belongs_to :equipment

## Key Features

- Strong parameters for all controllers
- `before_action` for show, update, destroy in both controllers
- `.includes(:category)` for N+1 query prevention
- Category existence validation on create/update
- Equipment existence validation on maintenance record create/update
- Cascade delete of maintenance records when equipment is destroyed
- Prevent category deletion if equipment exists (restrict_with_error)

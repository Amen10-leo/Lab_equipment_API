require "test_helper"

class MaintenanceRecordsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @category = Category.create!(name: "Test Category")
    @equipment = Equipment.create!(name: "Test Equipment", status: "available", category: @category)
    @maintenance_record = MaintenanceRecord.create!(equipment: @equipment, performed_at: Time.now, description: "Test maintenance")
  end

  test "should get index ordered by performed_at desc" do
    get maintenance_records_url
    assert_response :success
    json = JSON.parse(response.body)
    assert json.is_a?(Array)
  end

  test "should filter by equipment_id" do
    get maintenance_records_url, params: { equipment_id: @equipment.id }
    assert_response :success
    json = JSON.parse(response.body)
    assert json.all? { |mr| mr["equipment_id"] == @equipment.id }
  end

  test "should show maintenance record" do
    get maintenance_record_url(@maintenance_record)
    assert_response :success
    json = JSON.parse(response.body)
    assert json["equipment"].present?
  end

  test "should create maintenance record with valid equipment" do
    assert_difference("MaintenanceRecord.count") do
      post maintenance_records_url, params: { maintenance_record: { equipment_id: @equipment.id, performed_at: Time.now, description: "New maintenance" } }
    end
    assert_response :created
  end

  test "should not create maintenance record with invalid equipment" do
    post maintenance_records_url, params: { maintenance_record: { equipment_id: 99999, performed_at: Time.now, description: "New maintenance" } }
    assert_response :unprocessable_entity
  end

  test "should update maintenance record" do
    patch maintenance_record_url(@maintenance_record), params: { maintenance_record: { description: "Updated description" } }
    assert_response :success
  end

  test "should destroy maintenance record" do
    assert_difference("MaintenanceRecord.count", -1) do
      delete maintenance_record_url(@maintenance_record)
    end
    assert_response :no_content
  end
end

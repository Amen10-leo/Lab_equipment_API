require "test_helper"

class EquipmentControllerTest < ActionDispatch::IntegrationTest
  setup do
    @category = Category.create!(name: "Test Category")
    @equipment = Equipment.create!(name: "Test Equipment", status: "available", category: @category)
  end

  test "should get index ordered by name" do
    get equipment_index_url
    assert_response :success
    json = JSON.parse(response.body)
    assert json.is_a?(Array)
    # Verify ordered by name
    names = json.map { |e| e["name"] }
    assert_equal names.sort, names
  end

  test "should filter by status" do
    get equipment_index_url, params: { status: "available" }
    assert_response :success
    json = JSON.parse(response.body)
    assert json.all? { |e| e["status"] == "available" }
  end

  test "should include category name" do
    get equipment_index_url
    assert_response :success
    json = JSON.parse(response.body)
    assert json.first["category"].present?
    assert json.first["category"]["name"].present?
  end

  test "should show equipment with maintenance records" do
    MaintenanceRecord.create!(equipment: @equipment, performed_at: Time.now, description: "Test")
    get equipment_url(@equipment)
    assert_response :success
    json = JSON.parse(response.body)
    assert json["category"].present?
    assert json["maintenance_records"].is_a?(Array)
  end

  test "should create equipment with valid category" do
    assert_difference("Equipment.count") do
      post equipment_index_url, params: { equipment: { name: "New Equipment", status: "available", category_id: @category.id } }
    end
    assert_response :created
  end

  test "should not create equipment with invalid category" do
    post equipment_index_url, params: { equipment: { name: "New Equipment", status: "available", category_id: 99999 } }
    assert_response :unprocessable_entity
  end

  test "should update equipment" do
    patch equipment_url(@equipment), params: { equipment: { name: "Updated Name" } }
    assert_response :success
  end

  test "should destroy equipment and cascade maintenance records" do
    MaintenanceRecord.create!(equipment: @equipment, performed_at: Time.now, description: "Test")
    assert_difference("Equipment.count", -1) do
      assert_difference("MaintenanceRecord.count", -1) do
        delete equipment_url(@equipment)
      end
    end
    assert_response :no_content
  end
end

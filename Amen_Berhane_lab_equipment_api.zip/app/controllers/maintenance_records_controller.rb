class MaintenanceRecordsController < ApplicationController
  before_action :set_maintenance_record, only: [:show, :update, :destroy]

  # GET /maintenance_records
  # Supports filtering by equipment_id
  # Ordered by performed_at descending
  def index
    @maintenance_records = MaintenanceRecord.order(performed_at: :desc)

    if params[:equipment_id].present?
      @maintenance_records = @maintenance_records.where(equipment_id: params[:equipment_id])
    end

    if params[:status].present?
      @maintenance_records = @maintenance_records.where(status: params[:status])
    end

    render json: @maintenance_records.as_json(include: { equipment: { only: [:name, :status] } })
  end

  # GET /maintenance_records/:id
  # Includes equipment details
  def show
    render json: @maintenance_record.as_json(
      include: { equipment: { only: [:name, :status] } }
    )
  end

  # POST /maintenance_records
  # Accepts equipment_id in body. Verifies equipment exists.
  def create
    @equipment = Equipment.find_by(id: maintenance_record_params[:equipment_id])

    unless @equipment
      return render json: { error: "Equipment not found" }, status: :unprocessable_entity
    end

    @maintenance_record = MaintenanceRecord.new(maintenance_record_params)

    if @maintenance_record.save
      render json: @maintenance_record.as_json(include: { equipment: { only: [:name, :status] } }), status: :created
    else
      render json: { errors: @maintenance_record.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /maintenance_records/:id
  # Same validations as create
  def update
    if maintenance_record_params[:equipment_id].present?
      @equipment = Equipment.find_by(id: maintenance_record_params[:equipment_id])
      unless @equipment
        return render json: { error: "Equipment not found" }, status: :unprocessable_entity
      end
    end

    if @maintenance_record.update(maintenance_record_params)
      render json: @maintenance_record.as_json(include: { equipment: { only: [:name, :status] } })
    else
      render json: { errors: @maintenance_record.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # DELETE /maintenance_records/:id
  def destroy
    @maintenance_record.destroy
    head :no_content
  end

  private

  def set_maintenance_record
    @maintenance_record = MaintenanceRecord.find(params[:id])
  end

  def maintenance_record_params
    params.require(:maintenance_record).permit(:equipment_id, :performed_at, :description, :status, :technician_name)
  end
end

class EquipmentController < ApplicationController
  before_action :set_equipment, only: [:show, :update, :destroy]

  # GET /equipment
  # Ordered by name. Supports ?status=available filter.
  # Always includes category name. Uses .includes(:category)
  def index
    @equipment = Equipment.includes(:category).order(:name)

    if params[:status].present?
      @equipment = @equipment.where(status: params[:status])
    end

    render json: @equipment.as_json(include: { category: { only: :name } })
  end

  # GET /equipment/:id
  # Includes category and all maintenance records, ordered by performed_at descending
  def show
    render json: @equipment.as_json(
      include: [
        { category: { only: :name } },
        { maintenance_records: { order: 'performed_at DESC' } }
      ]
    )
  end

  # POST /equipment
  # Accepts category_id in body. Verifies category exists.
  def create
    @category = Category.find_by(id: equipment_params[:category_id])

    unless @category
      return render json: { error: "Category not found" }, status: :unprocessable_entity
    end

    @equipment = Equipment.new(equipment_params)

    if @equipment.save
      render json: @equipment.as_json(include: { category: { only: :name } }), status: :created
    else
      render json: { errors: @equipment.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /equipment/:id
  # Same validations as create
  def update
    if equipment_params[:category_id].present?
      @category = Category.find_by(id: equipment_params[:category_id])
      unless @category
        return render json: { error: "Category not found" }, status: :unprocessable_entity
      end
    end

    if @equipment.update(equipment_params)
      render json: @equipment.as_json(include: { category: { only: :name } })
    else
      render json: { errors: @equipment.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # DELETE /equipment/:id
  # Cascade deletes maintenance records (automatic via dependent: :destroy)
  def destroy
    @equipment.destroy
    head :no_content
  end

  private

  def set_equipment
    @equipment = Equipment.find(params[:id])
  end

  def equipment_params
    params.require(:equipment).permit(:name, :status, :category_id, :description, :serial_number)
  end
end

class Equipment < ApplicationRecord
  belongs_to :category
  has_many :maintenance_records, dependent: :destroy

  validates :name, presence: true
  validates :status, inclusion: { in: %w[available maintenance retired] }
  validates :category_id, presence: true
end

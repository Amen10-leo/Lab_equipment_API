class MaintenanceRecord < ApplicationRecord
  belongs_to :equipment

  validates :equipment_id, presence: true
  validates :performed_at, presence: true
  validates :description, presence: true
end

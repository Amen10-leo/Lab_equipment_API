# Create Categories
categories = Category.create!([
  { name: 'Microscopes', description: 'Optical and electron microscopes' },
  { name: 'Centrifuges', description: 'Laboratory centrifuges' },
  { name: 'Spectrometers', description: 'Mass and optical spectrometers' },
  { name: 'Incubators', description: 'Cell culture incubators' }
])

# Create Equipment
equipment = Equipment.create!([
  { name: 'Compound Microscope A', status: 'available', category: categories[0], serial_number: 'MIC-001' },
  { name: 'Electron Microscope B', status: 'maintenance', category: categories[0], serial_number: 'MIC-002' },
  { name: 'High-Speed Centrifuge', status: 'available', category: categories[1], serial_number: 'CEN-001' },
  { name: 'Mass Spectrometer X', status: 'retired', category: categories[2], serial_number: 'SPEC-001' },
  { name: 'CO2 Incubator', status: 'available', category: categories[3], serial_number: 'INC-001' }
])

# Create Maintenance Records
MaintenanceRecord.create!([
  { equipment: equipment[1], performed_at: 2.days.ago, description: 'Lens calibration and cleaning', technician_name: 'John Smith' },
  { equipment: equipment[1], performed_at: 1.month.ago, description: 'Routine inspection', technician_name: 'Jane Doe' },
  { equipment: equipment[2], performed_at: 1.week.ago, description: 'Rotor balance check', technician_name: 'Bob Johnson' },
  { equipment: equipment[3], performed_at: 3.months.ago, description: 'Final decommissioning service', technician_name: 'Alice Brown' }
])

puts "Seed data created successfully!"

class CreateMaintenanceRecords < ActiveRecord::Migration[7.1]
  def change
    create_table :maintenance_records do |t|
      t.references :equipment, null: false, foreign_key: true
      t.datetime :performed_at, null: false
      t.text :description, null: false
      t.string :status, default: 'completed'
      t.string :technician_name

      t.timestamps
    end

    add_index :maintenance_records, :performed_at
    add_index :maintenance_records, :equipment_id
  end
end

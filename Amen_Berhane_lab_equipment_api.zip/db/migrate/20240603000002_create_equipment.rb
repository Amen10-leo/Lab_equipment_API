class CreateEquipment < ActiveRecord::Migration[7.1]
  def change
    create_table :equipment do |t|
      t.string :name, null: false
      t.string :status, default: 'available', null: false
      t.references :category, null: false, foreign_key: true
      t.text :description
      t.string :serial_number

      t.timestamps
    end

    add_index :equipment, :name
    add_index :equipment, :status
  end
end

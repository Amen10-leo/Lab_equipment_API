require "active_support/core_ext/integer/time"

Rails.application.configure do
  # Settings specified here will take precedence over those in config/application.rb.

  # Code is not reloaded between requests.
  config.enable_reloading = false

  # Eager load code on boot.
  config.eager_load = true

  # Full error reports are disabled and caching is turned on.
  config.consider_all_requests_local = false

  # Ensures that a master key has been made available in ENV["RAILS_MASTER_KEY"], 
  # config/master.key, or an environment key such as config/credentials/production.key.
  # config.require_master_key = true

  # Disable serving static files from the `/public` folder.
  config.public_file_server.enabled = ENV["RAILS_SERVE_STATIC_FILES"].present?

  # Enable server timing
  config.server_timing = true

  # Run jobs in-line
  config.active_job.queue_adapter = :inline

  # Print deprecation notices to the Rails logger.
  config.active_support.deprecation = :log

  # Log to STDOUT by default
  config.logger = ActiveSupport::Logger.new(STDOUT)
    .tap  { |logger| logger.formatter = ::Logger::Formatter.new }
    .then { |logger| ActiveSupport::TaggedLogging.new(logger) }

  # Do not dump schema after migrations.
  config.active_record.dump_schema_after_migration = false
end

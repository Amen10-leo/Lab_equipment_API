Rails.application.routes.draw do
  resources :equipment do
    resources :maintenance_records, only: [:index]
  end

  resources :maintenance_records
  resources :categories
end
